//
//  SWIFTCODINGCHALLENGEApp.swift
//  SWIFTCODINGCHALLENGE
//
//  Created by admin67 on 24/12/25.
//

import SwiftUI

// @main
struct SWIFTCODINGCHALLENGEApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()       }
    }
}

